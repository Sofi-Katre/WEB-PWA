const staticCacheName = 'site-static-v1'
const assets = [
    '.',
    'index.html',
    'app.js',
    'img/icon.png',
    'style.css',
    'img/icon-128x128.png',
    'img/icon-192x192.png'
]

//событие install (вызывается при установке)

self.addEventListener('install', evt =>{
    evt.waitUntil(
        caches.open(staticCacheName).then((cache) =>{
            console.log('кеширование ресурсов')
            cache.addAll(assets)
        })
    )
})

//сщбытие activate (выбор версии кэша, обновление кэша)
self.addEventListener('activate', evt =>{
    evt.waitUntil(
        caches.keys().then(keys => {
            return Promise.all(keys
                .filter(key => key !== staticCacheName)
                .map(key => caches.delete(key))
            );
        })
    )
})

//событие fetch (вызывается при любом запросе к серверу)
self.addEventListener('fetch', evt =>{
    //если файл есть в кэше, то выдать из него. Иначе обратиться к серверу
    evt.respondWith(
        caches.match(evt.request).then(cacheRes =>{
            return cacheRes || fetch(evt.request)
        })
    )
})